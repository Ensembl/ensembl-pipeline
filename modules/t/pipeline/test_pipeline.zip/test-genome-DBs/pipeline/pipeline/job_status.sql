# MySQL dump 8.10
#
# Host: localhost    Database: glenn_pipeline_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'job_status'
#

CREATE TABLE job_status (
  job_id int(10) unsigned DEFAULT '0' NOT NULL,
  status varchar(40) DEFAULT 'CREATED' NOT NULL,
  time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  is_current enum('n','y') DEFAULT 'n',
  KEY job_id (job_id),
  KEY status (status),
  KEY is_current (is_current)
);
