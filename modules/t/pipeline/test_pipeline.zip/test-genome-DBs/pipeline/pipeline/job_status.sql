# MySQL dump 8.10
#
# Host: localhost    Database: glenn_pipeline_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'job_status'
#

CREATE TABLE job_status (
  job_id   int(10) unsigned NOT NULL,
  status   enum('CREATED', 'SUBMITTED', 'READING', 'WRITING',
                'RUNNING', 'SUCCESSFUL', 'FATAL', 'KILLED', 'FAILED') NOT NULL,
  time     datetime NOT NULL,

  KEY (job_id),
  KEY (status)
);
