CREATE TABLE job_status (
  job_id            int(10) unsigned NOT NULL,
  status            enum('CREATED', 'SUBMITTED', 'READING', 'WRITING',
                         'RUNNING', 'SUCCESSFUL', 'FATAL', 'KILLED', 'FAILED') NOT NULL,

  time              datetime NOT NULL,
  sequence_num      int unsigned NOT NULL auto_increment, 

  KEY (job_id),
  KEY (sequence_num)
);
