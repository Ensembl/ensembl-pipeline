# MySQL dump 8.10
#
# Host: localhost    Database: glenn_pipeline_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'config'
#

CREATE TABLE config (
  header varchar(255),
  key_name varchar(255),
  value varchar(255)
);
