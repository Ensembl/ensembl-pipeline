CREATE TABLE job (
  job_id            int(10) unsigned NOT NULL auto_increment,
  taskname          varchar(40) NOT NULL,
  input_id          varchar(40) NOT NULL,
  submission_id     varchar(40),
  array_index       varchar(255),
  parameters        varchar(255),
  module            varchar(255),
  stdout_file       varchar(100),
  stderr_file       varchar(100),

  PRIMARY KEY (job_id),
  KEY         (input_id),
  KEY         (taskname)
);


