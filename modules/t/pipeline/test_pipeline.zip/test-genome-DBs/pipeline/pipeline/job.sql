CREATE TABLE job (
  job_id            int unsigned NOT NULL auto_increment,
  taskname          varchar(255) NOT NULL,
  input_id          varchar(255) NOT NULL,
  submission_id     int unsigned,
  job_name          varchar(255),
  array_index       mediumint unsigned,
  parameters        varchar(255),
  module            varchar(255),
  stdout_file       varchar(255),
  stderr_file       varchar(255),
  retry_count       tinyint unsigned NOT NULL,

  PRIMARY KEY (job_id),
  KEY         (job_name, array_index),
  KEY         (input_id),
  KEY         (taskname)
);
