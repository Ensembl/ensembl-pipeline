# MySQL dump 8.10
#
# Host: localhost    Database: glenn_pipeline_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'job'
#

CREATE TABLE job (
  job_id int(10) unsigned NOT NULL auto_increment,
  input_id varchar(40) DEFAULT '' NOT NULL,
  analysis_id smallint(5) unsigned DEFAULT '0' NOT NULL,
  submission_id mediumint(10) unsigned DEFAULT '0' NOT NULL,
  stdout_file varchar(100) DEFAULT '' NOT NULL,
  stderr_file varchar(100) DEFAULT '' NOT NULL,
  retry_count tinyint(2) unsigned DEFAULT '0',
  PRIMARY KEY (job_id),
  KEY input_id (input_id),
  KEY analysis_id (analysis_id)
);
