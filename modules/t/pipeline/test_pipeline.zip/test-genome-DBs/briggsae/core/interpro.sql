# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'interpro'
#

CREATE TABLE interpro (
  interpro_ac varchar(40) DEFAULT '' NOT NULL,
  id varchar(40) DEFAULT '' NOT NULL,
  KEY interpro_ac (interpro_ac),
  KEY id (id)
);
