# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'exon_transcript'
#

CREATE TABLE exon_transcript (
  exon_id int(10) unsigned DEFAULT '0' NOT NULL,
  transcript_id int(10) unsigned DEFAULT '0' NOT NULL,
  rank int(10) DEFAULT '0' NOT NULL,
  PRIMARY KEY (exon_id,transcript_id,rank),
  KEY transcript (transcript_id)
);
