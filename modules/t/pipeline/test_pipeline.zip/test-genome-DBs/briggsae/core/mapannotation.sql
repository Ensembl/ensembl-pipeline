# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'mapannotation'
#

CREATE TABLE mapannotation (
  mapannotation_id int(10) unsigned NOT NULL auto_increment,
  mapfrag_id int(10) unsigned DEFAULT '0' NOT NULL,
  mapannotationtype_id smallint(5) unsigned DEFAULT '0' NOT NULL,
  value varchar(240) DEFAULT '' NOT NULL,
  PRIMARY KEY (mapannotation_id),
  KEY mapfrag_id (mapfrag_id,mapannotationtype_id),
  KEY mapannotationtype_id (mapannotationtype_id,mapfrag_id),
  KEY value (value,mapannotationtype_id),
  KEY mapannotationtype_id_2 (mapannotationtype_id,value)
);
