# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'mapannotationtype'
#

CREATE TABLE mapannotationtype (
  mapannotationtype_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(15) DEFAULT '' NOT NULL,
  name varchar(255) DEFAULT '' NOT NULL,
  description text DEFAULT '' NOT NULL,
  PRIMARY KEY (mapannotationtype_id),
  UNIQUE c (code)
);
