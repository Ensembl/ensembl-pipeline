CREATE TABLE qtl (
  qtl_id int unsigned auto_increment not null,
  trait varchar(255) not null,
  lod_score float,
  flank_marker_id_1 int,
  flank_marker_id_2 int,
  peak_marker_id int,
  primary key ( qtl_id ),
  key trait_idx( trait )
);
