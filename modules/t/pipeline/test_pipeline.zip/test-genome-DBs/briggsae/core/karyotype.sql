# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'karyotype'
#

CREATE TABLE karyotype (
  chromosome_id int(10) unsigned DEFAULT '0' NOT NULL,
  chr_start int(10) DEFAULT '0' NOT NULL,
  chr_end int(10) DEFAULT '0' NOT NULL,
  band varchar(40) DEFAULT '' NOT NULL,
  stain varchar(40) DEFAULT '' NOT NULL,
  PRIMARY KEY (chromosome_id,band)
);
