# MySQL dump 8.10
#
# Host: ecs1c    Database: mcvicker_markers
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'marker'
#

CREATE TABLE marker (
  marker_id int(10) unsigned NOT NULL auto_increment,
  display_marker_synonym_id int(10) unsigned,
  left_primer varchar(100) DEFAULT '' NOT NULL,
  right_primer varchar(100) DEFAULT '' NOT NULL,
  min_primer_dist int(10) unsigned DEFAULT '0' NOT NULL,
  max_primer_dist int(10) unsigned DEFAULT '0' NOT NULL,
  priority int(11),
  type enum('est', 'microsatellite'),
  PRIMARY KEY (marker_id),
  KEY marker_idx (marker_id,priority)
);
