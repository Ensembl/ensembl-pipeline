# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene'
#

CREATE TABLE gene (
  gene_id int(10) unsigned NOT NULL auto_increment,
  type varchar(40) DEFAULT '' NOT NULL,
  analysis_id int(11),
  transcript_count int(11) DEFAULT '0' NOT NULL,
  display_xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (gene_id),
  KEY xref_id_index (display_xref_id)
);
