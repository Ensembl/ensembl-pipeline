1	schema_version	$Revision: 1.206 $
2	schema_version	$Revision: 1.191.4.1 $
3	assembly.default	NCBI34
4	species.taxonomy_id	9606
5	species.classification	sapiens
6	species.classification	Homo
7	species.classification	Hominidae
8	species.classification	Catarrhini
9	species.classification	Primates
10	species.classification	Eutheria
11	species.classification	Mammalia
12	species.classification	Vertebrata
13	species.classification	Chordata
14	species.classification	Metazoa
15	species.classification	Eukaryota
16	species.common_name	Human
17	assembly.maxcontig	905058
18	genebuild.version	0405Ensembl
19	assembly.mapping	chromosome:NCBI34|contig
20	assembly.mapping	clone|contig
21	assembly.mapping	supercontig|contig
22	assembly.mapping	supercontig|contig|clone
23	assembly.mapping	chromosome:NCBI34|contig|clone
24	assembly.mapping	chromosome:NCBI34|contig|supercontig
