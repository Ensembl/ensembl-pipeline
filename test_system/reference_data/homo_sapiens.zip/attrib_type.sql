1	name	Name	
2	type	Type of feature	
3	htg_phase	HTG Phase	High Throughput Genome Phase
4	toplevel	Top Level	Top Level Non-Redundant Sequence Region
51	synonym	Alternate names for clone	Synonyms
52	FISHmap	FISH information	FISH map
53	organisation	Organisation sequencing clone	
54	state	Current state of clone	
55	BACend_flag	BAC end flags	
56	embl_acc	EMBL accession number	
57	superctg	Super contig id.	
58	seq_len	Accession length	
59	fp_size	FP size	
60	note	Note	
61	positioned_by	Positioned by	
62	bac_acc	BAC end accession	
63	plate	Plate	
70	bac_start	Start of BAC	
71	bac_end	End of BAC	
72	location	Location in well plate	
73	start_pos	Start positioned by	
74	end_pos	End positioned by	
75	mismatch	Mismatch	
76	non_ref	Non Reference	Non Reference Sequence Region
77	GeneCount	Gene Count	Total Number of Genes
78	KnownGeneCount	Known Gene Count	Total Number of Known Genes
79	PseudoGeneCount	PseudoGene Count	Total Number of PseudoGenes
80	SNPCount	SNP Count	Total Number of SNPs
134	probeName	Probe name	the name of the probe
135	compositeName	Composite name	the name of the composite
136	probeLength	Probe length	the length of the probe
137	matchLength	Match length	number of base matched
138	matchStatus	Match status	full_match or with_mismatch
