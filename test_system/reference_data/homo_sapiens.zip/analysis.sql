145	2004-06-10 09:57:57	SubmitChromosome	\N	\N	\N	\N	\N	\N	\N	SubmitAnalysis	\N	\N	\N
146	2004-06-10 09:57:57	Eponine	\N	\N	\N	eponine-scan	1	/usr/java/j2re1.4.2/bin/java	-epojar => /usr/local/ensembl/lib/eponine-scan.jar, -threshold => 0.999	EponineTSS	\N	Eponine	TSS
147	2004-06-10 09:57:57	FirstEF	\N	\N	\N	firstef	\N	firstef	-repeatmasked => 1, -parameters_dir => /usr/local/ensembl/lib/firstef/parameters, -parse_script => /usr/local/ensembl/lib/firstef/FirstEF_parser.pl	FirstEF	\N	firstef	exon
148	2004-06-10 09:57:57	RepeatMask	repbase	020713	\N	RepeatMasker	1	RepeatMasker	\N	RepeatMasker	\N	RepeatMasker	repeat
149	2004-06-10 09:57:57	tRNAscan	tRNA	1	\N	tRNAscan-SE	1.11	tRNAscan-SE	\N	tRNAscan_SE	\N	tRNAscan-SE	tRNA
150	2004-06-10 09:57:57	Genscan	HumanIso.smat	1	HumanIso.smat	genscan	1.0	genscan	\N	Genscan	\N	genscan	prediction
151	2004-06-10 09:57:57	SubmitGenome	\N	\N	\N	\N	\N	\N	\N	SubmitAnalysis	\N	\N	\N
152	2004-06-10 09:57:57	SubmitContig	\N	\N	\N	\N	\N	\N	\N	SubmitAnalysis	\N	\N	\N
153	2004-06-10 09:57:57	Vertrna	embl_vertrna	020917	embl_vertrna	wutblastn	1	wutblastn	-hitdist=40 -cpus=1	BlastGenscanDNA	\N	wutblastn	similarity
154	2004-06-10 09:57:57	marker	\N	\N	\N	e-PCR	1	e-PCR	-M=>150,-W=>7,-NMIN=>0, -NMAX=>2	EPCR	\N	e-PCR	sts
155	2004-06-10 09:57:57	Swall	swall	020916	swall	wublastp	1	wublastp	-hitdist=40 -cpus=1	BlastGenscanPep	\N	wublastp	similarity
156	2004-06-10 09:57:57	SubmitSlice	\N	\N	\N	\N	\N	\N	\N	SubmitAnalysis	\N	\N	\N
157	2004-06-10 09:57:57	CpG	cpg	\N	\N	cpg	1	cpg	\N	CPG	\N	cpg	cpg_island
158	2004-06-10 09:57:57	Unigene	uniuni	020919	uniuni	wutblastn	1	wutblastn	-hitdist=40 -cpus=1	BlastGenscanDNA	\N	wutblastn	similarity
159	2004-06-10 09:57:57	Dust	Dust	\N	\N	dust	1	tcdust	\N	Dust	\N	dust	dust
160	2004-06-10 09:57:57	TRF	TRF	\N	\N	trf	1	trf	\N	TRF	\N	trf	tandem_repeat
161	2004-06-24 10:38:52	RepeatMask_Wait	\N	\N	\N	\N	\N	\N	\N	Accumulator	\N	\N	\N
162	2004-06-10 09:57:57	test_vertrna	embl_vertrna	020917	embl_vertrna	wutblastn	1	wutblastn	-hitdist=40 -cpus=1	BlastGenscanDNA	\N	wutblastn	similarity
163	2004-09-01 14:51:31	Fgenesh	hum.dat	\N	hum.dat	fgenesh	\N	fgenesh	\N	Fgenesh	\N	\N	\N
