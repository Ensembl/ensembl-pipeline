1	chromosome	NCBI34	1	default_version
2	supercontig	\N	2	default_version
3	clone	\N	3	default_version
4	contig	\N	4	default_version,sequence_level
