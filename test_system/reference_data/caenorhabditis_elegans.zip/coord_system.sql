3	clone	\N	2	default_version,sequence_level
4	chromosome	CEL116	1	default_version
