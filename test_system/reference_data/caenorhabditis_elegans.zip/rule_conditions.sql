1	SubmitSlice
2	SubmitContig
3	RepeatMask
