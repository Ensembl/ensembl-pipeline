1	schema_version	$Revision: 1.212 $
2	assembly.mapping	chromosome:CEL116|clone
27	species.taxonomy_id	6239
28	species.common_name	C.elegans
29	species.classification	elegans
30	species.classification	Caenorhabditis
31	species.classification	Peloderinae
32	species.classification	Rhabditidae
33	species.classification	Rhabditoidea
34	species.classification	Rhabditida
35	species.classification	Chromadorea
36	species.classification	Nematoda
37	species.classification	Metazoa
38	species.classification	Eukaryota
39	assembly.default	CEL116
40	genebuild.version	0402Wormbase
