1	toplevel	Top Level	Top Level Non-Redundant Sequence Region
2	GeneCount	Gene Count	Total Number of Genes
3	KnownGeneCount	Known Gene Count	Total Number of Known Genes
4	PseudoGeneCount	PseudoGene Count	Total Number of PseudoGenes
