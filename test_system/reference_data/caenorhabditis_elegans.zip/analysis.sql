1	2004-01-05 12:54:09	Genefinder	\N	\N	\N	Genefinder	1	\N	\N	Genefinder	\N	Genefinder	prediction
2	2004-01-05 12:54:09	Snap	worm	\N	/usr/local/ensembl/Zoe/HMM/worm	snap	\N	/usr/local/ensembl/Zoe/bin/snap	\N	Snap	\N	\N	\N
3	2004-01-05 12:54:09	RepeatMask	\N	\N	\N	RepeatMasker	1	RepeatMasker	-low -el	RepeatMasker	\N	RepeatMasker	repeat
4	0000-00-00 00:00:00	SubmitContig	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	0000-00-00 00:00:00	SubmitSlice	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
